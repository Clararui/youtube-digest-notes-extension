const key = "ytd_notes";
const count = document.getElementById("count");
const status = document.getElementById("status");
const fileInput = document.getElementById("importFile");
const importButton = document.getElementById("importBtn");
let incomingNotes = null;

function report(message, error = false) {
  status.textContent = message;
  status.classList.toggle("error", error);
}

function validateNotes(value) {
  if (!Array.isArray(value) || !value.every((note) => note && typeof note === "object" && !Array.isArray(note) && typeof note.text === "string")) {
    throw new Error("文件中没有有效的 Notes 列表，请选择本页面导出的备份文件。");
  }
  return value;
}

async function readNotes() {
  const stored = await chrome.storage.local.get(key);
  return validateNotes(stored[key] ?? []);
}

async function refreshCount() {
  count.textContent = String((await readNotes()).length);
}

function downloadNotes(notes) {
  const payload = {
    format: "youtube-digest-notes-backup",
    formatVersion: 1,
    exportedAt: new Date().toISOString(),
    notes,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `youtube-digest-notes-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

document.getElementById("version").textContent = chrome.runtime.getManifest().version;
refreshCount().catch((error) => report(`读取失败：${error.message}`, true));

document.getElementById("exportBtn").addEventListener("click", async () => {
  try {
    const notes = await readNotes();
    downloadNotes(notes);
    report(`已下载 ${notes.length} 条 Notes 的备份。请先确认下载文件存在。`);
  } catch (error) {
    report(`备份失败：${error.message}`, true);
  }
});

fileInput.addEventListener("change", async () => {
  incomingNotes = null;
  importButton.disabled = true;
  const file = fileInput.files?.[0];
  if (!file) return;
  try {
    if (file.size > 10 * 1024 * 1024) throw new Error("文件超过 10 MB，请检查是否选择了正确的备份。");
    const parsed = JSON.parse(await file.text());
    if (parsed?.format !== "youtube-digest-notes-backup" || parsed?.formatVersion !== 1) {
      throw new Error("这不是 YouTube Digest Notes 备份文件。");
    }
    incomingNotes = validateNotes(parsed.notes);
    importButton.disabled = false;
    report(`已读取 ${incomingNotes.length} 条 Notes。点击“确认合并导入”后才会写入。`);
  } catch (error) {
    report(`无法导入：${error.message}`, true);
  }
});

importButton.addEventListener("click", async () => {
  if (!incomingNotes) return;
  importButton.disabled = true;
  try {
    const current = await readNotes();
    const seen = new Set(current.filter((note) => note.id != null).map((note) => String(note.id)));
    const merged = [...current];
    let added = 0;
    for (const note of incomingNotes) {
      const id = note.id == null ? null : String(note.id);
      if (id !== null && seen.has(id)) continue;
      if (id !== null) seen.add(id);
      merged.push(note);
      added += 1;
    }
    await chrome.storage.local.set({ [key]: merged });
    const verified = await readNotes();
    if (verified.length !== merged.length) throw new Error("写入后数量不一致，请暂时保留备份并重试。");
    await refreshCount();
    report(`完成：新增 ${added} 条，跳过 ${incomingNotes.length - added} 条重复 Notes，现在共有 ${verified.length} 条。`);
  } catch (error) {
    report(`导入失败：${error.message} 原备份文件未更改。`, true);
  } finally {
    importButton.disabled = false;
  }
});
